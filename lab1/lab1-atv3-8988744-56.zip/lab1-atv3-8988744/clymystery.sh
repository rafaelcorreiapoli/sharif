cat README.md
cd misterio
grep "PISTA" cena-do-crime
head pessoas
grep "Annabel" pessoas
head -n 40 ruas/Vila_Hart | tail -n 1
head -n 179 ruas/Vila_Buckingham | tail -n 1
cd entrevistas
cat entrevista-47246024
cat entrevista-699607
cd ..
grep -A 5 "L337" automoveis
grep "Jacqui Maher" pessoas
cd associacoes
cat AAA | grep "Joe Germuska"
cat AAA | grep "Jeremy Bowers"
cat Delta_SkyMiles | grep "Joe Germuska"
cat Delta_SkyMiles | grep "Jeremy Bowers"
cat Biblioteca_da_Cidade | grep "Jeremy Bowers"
cat Museu_da_História_do_Bash | grep "Jeremy Bowers"
cd ..
grep "Jeremy Bowers" pessoas
cd ruas
head -n 284 Travessa_Dunstable | tail -n 1
cd ..
cd entrevistas
cat entrevista-9620713
echo "Jeremy Bowers"


