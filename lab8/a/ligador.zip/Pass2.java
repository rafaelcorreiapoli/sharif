package linker;

import java.io.IOException;
import java.util.StringTokenizer;

import mvn.util.LinkerSymbolTable;

/**
 * Passo 2 do ligador.<br>
 * Nesse passo é gerado o código objeto a partir da tabela
 * de símbolos obtida.
 * @author FLevy
 * @version 23.10.2006
 * Preparação do arquivo para alunos - PSMuniz 1.11.2006
 * @version 01.01.2010 : atualização da classe de acordo com a definição dos slides. (Tiago)
 */
public class Pass2 extends Pass {

    /**Gerencia o arquivo de saída*/
    private Output out;
    /**Tabela de símbolos utilizada pelo Linker*/
    private LinkerSymbolTable symbolTable;
    /**Indica o endereçamento corrente da parte relocável do código. */
    private int relativeLocationCouter;
    /**A base de relocação a ser considerada no código. */
    private int base;

    /**Contador de variáveis externas que não foram resolvidas*/
    private int externalCounter = 0;


    public Pass2(LinkerSymbolTable symbolTable, String objFile) throws IOException {
        out = new Output(objFile);
        this.symbolTable = symbolTable;
        relativeLocationCouter = 0;
        base = 0;
    }

    /**
     * Processa uma linha de código.
     *
     * @param nibble O nibble do endereço da linha.
     * @param address O endereço da linha (sem o nibble).
     * @param code O código da linha.
     * @param currentFile O arquivo atual que está sendo processado.
     * @return Verdadeiro caso a análise teve sucesso, falso caso contrario.
     * @exception ! Caso tenha ocorrido algum problema de IO.
     */
    protected boolean processCode(int nibble, String address, String code, String currentFile)
            throws IOException {
        /*
         *
         *
         * Aqui, deve-se gerar o código objeto a partir da tabela de simbolos (ST).
         * Deve-se avaliar as combinações apropriadas do nibble. Se houver pendência (relocável
         * ou absoluta), ela deve ter ser resolvida e seu valor inserido na ST.
         * O código resolvido deve ser enviado para a saída.
         *
         */
        int var12 = Integer.parseInt(address, 16);
        String var5 = code;
        boolean var6 = false;
        if(isRelocableEntryPoint(nibble)) {
            var6 = true;
        }

        boolean var7 = false;
        if(isRelocable(nibble)) {
            var12 += this.base;
            var7 = true;
            this.relativeLocationCouter += 2;
        }

        int var8 = Integer.parseInt(code.substring(1), 16);
        String var9 = this.symbolTable.getAddressByCode(currentFile, var8);
        boolean var10 = true;
        if(var9 != null && var9.startsWith("5") && (nibble == 5 || nibble == 13)) {
            var10 = false;
        }

        if((var9 = (var9 = "0000" + var9).substring(var9.length() - 3, var9.length())) != null) {
            if(nibble % 2 == 1) {
                LinkerSymbolTable var11;
                var6 = this.symbolTable.isRelocable(this.symbolTable.getSymbol(currentFile, var8));
                var5 = code.substring(0, 1) + var9;
            }

            if((nibble >> 2) % 2 != 0) {
                var5 = code.substring(0, 1) + var9;
            }
        } else if(nibble % 2 == 1) {
            var5 = code;
        }

        if(isRelocableEntryPoint(nibble)) {
            nibble = Integer.parseInt(var5, 16) + this.base;
            var5 = (var5 = "0000" + Integer.toHexString(nibble)).substring(var5.length() - 4, var5.length());
        }

        this.out.write(var12, var5, var7, var6, var10);
        return true;

    }//method

    protected boolean processSymbolicalAddress(int nibble, String address, String symbol, String currentFile, String originalLine)
            throws IOException {
        
        /**
         *
         * Tratamento do Endereçamento simbólico. 
         * Caso EntryPoint: escreve no arquivo de saída
         * Caso External: se resolvido ignora, caso contrário insere na tabela o arquivo com um novo endereçamento "virtual"
         *                  e escreve o external no arquivo de saída.
         * 
         *          
         */

        //Se for símbolo exportável: gero no arquivo de saída as informações a respeito dele
        //...
        //...
        if(isEntryPoint(nibble)) {
            this.out.writeExternal(Integer.toHexString(nibble), Integer.parseInt(this.symbolTable.getSymbolValue(symbol), 16), originalLine);
            return true;
        } else {
            if(!this.symbolTable.definedSymbol(symbol)) {
                this.symbolTable.insertSymbol(symbol);
                String var6 = "0000" + Integer.toHexString(this.externalCounter);
                var6 = "5" + var6.substring(var6.length() - 3, var6.length());
                this.symbolTable.setSymbolValue(symbol, var6);
                this.out.writeExternal("4", Integer.parseInt(this.symbolTable.getSymbolValue(symbol), 16), originalLine);
                ++this.externalCounter;
            }

            StringTokenizer var7 = new StringTokenizer(originalLine);
            this.symbolTable.setCodeForSymbol(symbol, currentFile, Integer.parseInt(var7.nextToken().substring(1, 4), 16));
            return true;
        }
    }

    /**
     * Finaliza o arquivo lido (pode haver um próximo arquivo).
     */
    protected void fileEnd() {
        /*
         *
         * Quando há mudança de arquivo, deve-se atualizar a base e o relativeLocationCounter!
         * */
        this.base += this.relativeLocationCouter;
        this.relativeLocationCouter = 0;
    }

    public void closeOutput() throws IOException {
        out.close();
    }
}
