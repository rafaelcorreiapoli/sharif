package linker;

import java.io.IOException;
import java.util.StringTokenizer;

import mvn.util.LinkerSymbolTable;

/**
 * Passo 2 do ligador.<br>
 * Nesse passo é gerado o código objeto a partir da tabela
 * de símbolos obtida.
 * @author FLevy
 * @version 23.10.2006
 * Preparação do arquivo para alunos - PSMuniz 1.11.2006
 * @version 01.01.2010 : atualização da classe de acordo com a definição dos slides. (Tiago)
 */
public class Pass2 extends Pass {

    /**Gerencia o arquivo de saída*/
    private Output out;
    /**Tabela de símbolos utilizada pelo Linker*/
    private LinkerSymbolTable symbolTable;
    /**Indica o endereçamento corrente da parte relocável do código. */
    private int relativeLocationCouter;
    /**A base de relocação a ser considerada no código. */
    private int base;

    /**Contador de variáveis externas que não foram resolvidas*/
    private int externalCounter = 0;


    public Pass2(LinkerSymbolTable symbolTable, String objFile) throws IOException {
        out = new Output(objFile);
        this.symbolTable = symbolTable;
        relativeLocationCouter = 0;
        base = 0;
    }

    /**
     * Processa uma linha de código.
     *
     * @param nibble O nibble do endereço da linha.
     * @param address O endereço da linha (sem o nibble).
     * @param code O código da linha.
     * @param currentFile O arquivo atual que está sendo processado.
     * @return Verdadeiro caso a análise teve sucesso, falso caso contrario.
     * @exception Caso tenha ocorrido algum problema de IO.
     */
    protected boolean processCode(int nibble, String address, String code, String currentFile)
            throws IOException {
     
    	String finalCode = code;
        int finalAddress;
        int finalNibble = nibble;
        int opcode = Integer.parseInt(code.substring(0, 1), 16);

         if (instructionWithExternal(nibble)) {
            int numeric = Integer.parseInt(code, 16)%Integer.parseInt("1000", 16);
            String symbol = symbolTable.getSymbol(currentFile, numeric);

            int argument = Integer.parseInt(symbolTable.getSymbolValue(symbol), 16);
            finalCode = Integer.toHexString(4096 * opcode + argument);

            finalNibble -= 5;
            if (symbolTable.isRelocable(symbol))
                finalNibble += 2;
         }

        if (isRelocable(finalNibble)) {
            finalAddress =relativeLocationCouter + base;
            relativeLocationCouter += 2;
        } else {
            finalAddress = Integer.parseInt(address, 16);
        }

        out.write(finalAddress, finalCode, isRelocable(finalNibble), isArgumentRelocable(finalNibble), isResolved(finalNibble));

         return true;

    }//method

    protected boolean processSymbolicalAddress(int nibble, String address, String symbol, String currentFile, String originalLine)
            throws IOException {

    	int finalAdress;
        boolean relocable;

        if (isEntryPoint(nibble)) {
            finalAdress = Integer.parseInt(symbolTable.getSymbolValue(symbol), 16);
            relocable = symbolTable.isRelocable(symbol);
        } else if (isExternalPseudoInstruction(nibble)) {
            if (isResolved(nibble))
                return true;
            return true;
        } else {
            return false;
        }

        int finalNibble = 0;
        if (relocable) finalNibble += 2;

        out.writeExternal(Integer.toHexString(finalNibble), finalAdress, originalLine);
        return true;
    }

    /**
     * Finaliza o arquivo lido (pode haver um próximo arquivo).
     */
    protected void fileEnd() {
    	 base += relativeLocationCouter;
         relativeLocationCouter = 0;
    }

    public void closeOutput() throws IOException {
        out.close();
    }
}
